/* 
 * File:   Distance.cpp
 * Author: felixfan
 * 
 * Created on November 17, 2014, 4:56 PM
 */

#include "Distance.h"

Distance::Distance() {
}

Distance::Distance(const Distance& orig) {
}

Distance::~Distance() {
}

double Distance::EuclideanDistance(const MatrixXd &mf, const MatrixXd &ms, int n){
    /*
     Euclidean Distance
     */
    double diag = 0;
    double upper =0;
    for(int i=0; i<n; i++){
        diag += pow(mf(i,i)*1.0 - ms(i,i),2);
        for(int j=i+1; j<n; j++){
            upper += pow(mf(i,j)*1.0 - ms(i,j), 2);
        }
    }
    double result = diag + upper * 2.0;
    result = sqrt(result);
    return result;
}

double Distance::oneNorm(const MatrixXd &mf, const MatrixXd &ms, int n){
    /*
     The 1-norm: the maximum absolute column sum
     */
    MatrixXd md(n, n);
    md = mf - ms;
    
    double maxColSum =0;
    for(int i=0; i<n; i++){
        double colSum=0;
        for(int j=0; j<n; j++){
            colSum += abs(md(i,j));
        }
        if(colSum > maxColSum){
            maxColSum = colSum;
        }
    }
    
    return maxColSum;
}

double Distance::infNorm(const MatrixXd &mf, const MatrixXd &ms, int n){
    /*
     The infinity norm: the maximum absolute row sum
     */
    
    MatrixXd md(n, n);
    md = mf - ms;
    
    double maxRowSum =0;
    for(int i=0; i<n; i++){
        double rowSum=0;
        for(int j=0; j<n; j++){
            rowSum += abs(md(j,i));
        }
        if(rowSum > maxRowSum){
            maxRowSum = rowSum;
        }
    }
    
    return maxRowSum;
}
