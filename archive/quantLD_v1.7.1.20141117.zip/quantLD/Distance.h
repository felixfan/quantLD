/* 
 * File:   Distance.h
 * Author: felixfan
 *
 * Created on November 17, 2014, 4:56 PM
 */

#ifndef DISTANCE_H
#define	DISTANCE_H

#include <iostream>
#include <vector>
#include <cmath>
#include "Eigen/Dense"

using namespace std;
using namespace Eigen;


class Distance {
public:
    Distance();
    Distance(const Distance& orig);
    virtual ~Distance();
    double EuclideanDistance(const MatrixXd &mf, const MatrixXd &ms, int n);
    double oneNorm(const MatrixXd &mf, const MatrixXd &ms, int n);
    double infNorm(const MatrixXd &mf, const MatrixXd &ms, int n);
private:

};

#endif	/* DISTANCE_H */

