/* 
 * File:   test.h
 * Author: felixfan
 *
 * Created on November 6, 2014, 4:02 PM
 */

#ifndef TEST_H
#define	TEST_H



class test {
public:
    test();
    test(const test& orig);
    virtual ~test();
    void testPWM();
private:
    
};

#endif	/* TEST_H */

