/* 
 * File:   run.cpp
 * Author: fan
 * 
 * Created on October 7, 2014, 2:35 PM
 */
#include <sstream>
#include "run.h"

run::run() {
}

run::run(const run& orig) {
}

run::~run() {
}

void run::runQuantLDStep(string fileName1, string fileName2, int fPM, int windowSize, string method, int perm, string ldMeasure, string ldMethod,bool fisher, string outName, int maxWin){
    ifstream myfile(fileName1.c_str());
    int lines = 0;  
    string temp;
    while(myfile){
        if (!getline(myfile,temp)) break;
        lines++;
    }
    myfile.close(); 
    int maxlines = maxWin * windowSize;
    int iter = lines / maxlines + 1;   // split file into multiple parts, read it one by one
    
    int start, end;
    for(int zzz=0; zzz < iter; zzz++){
        if(zzz==0){
            start = 1;
            end = maxlines;
        }else{
            start = end - windowSize + 1;
            end = maxlines + maxlines * zzz;
        }
        // read and code data  
        vector<vector<string> > data1 = rf.readTable(fileName1, start, end);
        vector<vector<int> > genoCode1 = rf.codeGenotype(data1);   
        vector<vector<string> > data2 = rf.readTable(fileName2, start, end);
        vector<vector<int> > genoCode2 = rf.codeGenotype(data2);

        // Window information
        vector<vector<string> > chrRSpos;
        for(int i=0; i < data1.size()-windowSize+1; i++){
            vector<string> temp;
            temp.push_back(data1[i][0]);        
            temp.push_back(data1[i][1]);
            temp.push_back(data1[i][3]);
            temp.push_back(data1[i+windowSize-1][1]);       
            temp.push_back(data1[i+windowSize-1][3]);
            chrRSpos.push_back(temp);
        }

        // calculate sample size
        auto t98 = genoCode1.begin();
        int n1 = t98->size();   
        auto t99 = genoCode2.begin();
        int n2 = t99->size();

        // calculate LD measure
        vector<vector<double> > fr, sr; 
        fr = myCalLD.calRD(genoCode1, windowSize, ldMeasure, ldMethod);
        sr = myCalLD.calRD(genoCode2, windowSize, ldMeasure, ldMethod);        
        
        // log
        if(zzz==0){
            cout << "read data from " << fileName1 << endl;
            cout << "there are " << n1 << " individuals and " << lines << " SNPs" << endl;
            cout << "read data from " << fileName2 << endl;
            cout << "there are " << n2 << " individuals and " << lines << " SNPs" << endl;
            if(ldMeasure == "r2"){
                cout << "calculate r squared" << endl;
                cout << "compare r squared matrices" << endl << endl;
            }else{
                cout << "calculate D prime" << endl;
                cout << "compare D prime matrices" << endl << endl;
            }            
        }
        cout << "chunk " << zzz+1 << "/" << iter << endl;   
        
        // run the selected method
        vector<double> rtmtpevdstjt;
        vector<vector<double> > rtmtpevdstjtperm;
        vector<string> header = headerInfo(fPM, method);
         
        switch(mmethod[method]){
            case 1:
            case 2:
            case 3:
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
                if(fPM==0){
                    rtmtpevdstjt= pwp.pwTMTPEVD(fr, sr, windowSize, method);
                }else{
                    rtmtpevdstjtperm= pwp.pwTMTPEVDperm(fr, sr, genoCode1, genoCode2, windowSize, method, perm, n1, n2, ldMeasure,ldMethod);
                }
                break;
            case 4:
            case 5:
                rtmtpevdstjtperm= pwp.pwSTJTALL(fr, sr, windowSize, method, n1, n2,fisher);
                break;
            case 11:
                if(fPM==0){
                    rtmtpevdstjtperm= pwp.pwSTJTALL(fr, sr, windowSize, method, n1, n2,fisher);
                }else{
                    rtmtpevdstjtperm= pwp.pwAllPerm(fr, sr, genoCode1, genoCode2, windowSize, perm, n1, n2, ldMeasure,ldMethod,fisher);
                }
                break;
        }
        
        if(zzz==0){
            if(fPM==1 || method=="steiger" || method=="jennrich" || method=="all"){
                wf.write2dVectorToTable(chrRSpos, rtmtpevdstjtperm, outName, header);
            }else{ 
                wf.writeVectorToTable(chrRSpos, rtmtpevdstjt, outName, header);
            }            
        }else{
            if(fPM==1 || method=="steiger" || method=="jennrich" || method=="all"){
                wf.write2dVectorToTable(chrRSpos, rtmtpevdstjtperm, outName);
            }else{
                wf.writeVectorToTable(chrRSpos, rtmtpevdstjt, outName);
            }  
        }
        
    }
}

// only read from from-bp to to-bp, and take this region as a window
int run::runQuantLDOne(string fileName1, string fileName2, int fPM, string method, int perm, string ldMeasure, string ldMethod, string outName, string fromBP, string toBP,bool fisher){
    int start, end;
    ifstream myfile(fileName1.c_str()); 
    string temp;
    bool findStart=false, findEnd=false;
    int lines =0;
    
    // check from-bp and to-bp
    while(myfile){
        if (!getline(myfile,temp)) break;
        lines++;
        istringstream iss(temp);
        
        while(iss){
            string s;
            if (!getline(iss, s, ' ')) break;
            if (s ==fromBP){
                start = lines;
                findStart=true;
                break;
            }else if(s == toBP){
                end = lines;
                findEnd=true;
                break;
            }
        }
        
        if(findEnd==true){
            break;
        }
    }
    myfile.close(); 
    
    if(findEnd !=true){
        cout << toBP << " not found" << endl;
        return -1;
    }else if(findStart !=true){
        cout << fromBP << " not found" << endl;
        return -1;
    }
    
    // calculate windowSize
    int windowSize = end - start + 1;
        
    // read and code data  
    vector<vector<string> > data1 = rf.readTable(fileName1, start, end);
    vector<vector<int> > genoCode1 = rf.codeGenotype(data1);   
    vector<vector<string> > data2 = rf.readTable(fileName2, start, end);
    vector<vector<int> > genoCode2 = rf.codeGenotype(data2);

    // Window information
    vector<string> chrRSpos;
    chrRSpos.push_back(data1[0][0]);        
    chrRSpos.push_back(data1[0][1]);
    chrRSpos.push_back(data1[0][3]);
    chrRSpos.push_back(data1[data1.size()-1][1]);
    chrRSpos.push_back(data1[data1.size()-1][3]);
    
    // calculate sample size
    auto t98 = genoCode1.begin();
    int n1 = t98->size();   
    auto t99 = genoCode2.begin();
    int n2 = t99->size();
    
    // log
    cout << "read data from " << fileName1 << endl;
    cout << "there are " << n1 << " individuals and " << genoCode1.size() << " SNPs" << endl;
    cout << "read data from " << fileName2 << endl;
    cout << "there are " << n2 << " individuals and " << genoCode2.size() << " SNPs" << endl;
    if(ldMeasure == "r2"){
        cout << "calculate r squared" << endl;
        cout << "compare r squared matrices" << endl << endl;
    }else{
        cout << "calculate D prime" << endl;
        cout << "compare D prime matrices" << endl << endl;
    }           
    
    // calculate LD measure
    vector<vector<double> > fr, sr; 
    fr = myCalLD.calRD(genoCode1, windowSize, ldMeasure, ldMethod);
    sr = myCalLD.calRD(genoCode2, windowSize, ldMeasure, ldMethod);        

    // run the selected method
    vector<double> rtmtpevdstjt;
    vector<vector<double> > rtmtpevdstjtperm;       
    vector<string> header = headerInfo(fPM, method);
         
    switch(mmethod[method]){
        case 1:
        case 2:
        case 3:
        case 6:
        case 7:
        case 8:
        case 9:
        case 10:
            if(fPM==0){
                rtmtpevdstjt= pwp.pwTMTPEVD(fr, sr, windowSize, method);
            }else{
                rtmtpevdstjtperm= pwp.pwTMTPEVDperm(fr, sr, genoCode1, genoCode2, windowSize, method, perm, n1, n2, ldMeasure,ldMethod);
            }
            break;
        case 4:
        case 5:
            rtmtpevdstjtperm= pwp.pwSTJTALL(fr, sr, windowSize, method, n1, n2,fisher);
            break;
        case 11:
            if(fPM==0){
                rtmtpevdstjtperm= pwp.pwSTJTALL(fr, sr, windowSize, method, n1, n2,fisher);
            }else{
                rtmtpevdstjtperm= pwp.pwAllPerm(fr, sr, genoCode1, genoCode2, windowSize, perm, n1, n2, ldMeasure,ldMethod,fisher);
            }
    }
        
       
    // write output
    if(fPM==1 || method=="steiger" || method=="jennrich" || method=="all"){       
        wf.write2dVectorToTable0(chrRSpos, rtmtpevdstjtperm, outName, header);
    }else{
        wf.writeVectorToTable0(chrRSpos, rtmtpevdstjt, outName, header);
    }            
    
    return 0;
}


vector<string> run::headerInfo(int flag, string method){
    // ST.P ST.Chisq ST.df JT.P JT.Chisq JT.df TM TP EVD FD MHD MSD CAD CHD TM.P TP.P EVD.P FD.P MHD.P MSD.P CAD.P CHD.P
    vector<string> header;
    if(flag==0){ // no permutation
        switch(mmethod[method]){
            case 1:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "TM"};
                break;
            case 2:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "TP"};
                break;
            case 3:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "EVD"};
                break;
            case 4:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "ST.P", "ST.Chisq", "ST.df"}; 
                break;
            case 5:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "JT.P", "JT.Chisq", "JT.df"};
                break;
            case 6:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "FD"};
                break;
            case 7:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "MHD"};
                break;
            case 8:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "MSD"};
                break;
            case 9:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "CAD"};
                break;
            case 10:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "CHD"};
                break;
            case 11:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2","ST.P", "ST.Chisq", "ST.df", "JT.P", "JT.Chisq", "JT.df", \
                        "TM", "TP", "EVD", "FD", "MHD", "MSD", "CAD", "CHD"};
                break;
        }
    }else{ // permutation
        switch(mmethod[method]){
            case 1:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "TM","TM.P"};
                break;
            case 2:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "TP","TP.P"};
                break;
            case 3:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "EVD","EVD.P"};
                break;
            case 4:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "ST.P", "ST.Chisq", "ST.df"}; 
                break;
            case 5:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "JT.P", "JT.Chisq", "JT.df"};
                break;
            case 6:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "FD","FD.P"};
                break;
            case 7:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "MHD","MHD.P"};
                break;
            case 8:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "MSD","MSD.P"};
                break;
            case 9:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "CAD","CAD.P"};
                break;
            case 10:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2", "CHD","CHD.P"};
                break;
            case 11:
                header={"CHR", "SNP1", "POS1", "SNP2", "POS2","ST.P", "ST.Chisq", "ST.df", "JT.P", "JT.Chisq", "JT.df", \
                        "TM", "TP", "EVD", "FD", "MHD", "MSD", "CAD", "CHD",\
                        "TM.P", "TP.P", "EVD.P", "FD.P", "MHD.P", "MSD.P", "CAD.P", "CHD.P"};
                break;
        }
    }
    return header;
}