/* 
 * File:   writeFile.h
 * Author: fan
 *
 * Created on September 23, 2014, 9:49 AM
 */

#ifndef WRITEFILE_H
#define	WRITEFILE_H

using namespace std;

class writeFile {
public:
    writeFile();
    writeFile(const writeFile& orig);
    virtual ~writeFile();
    int writeVectorToTable(const vector<vector<string> > &infor, const vector<double> &v, string fileName, vector<string> header);
    int write2dVectorToTable(const vector<vector<string> > &infor, const vector<vector<double> > &v, string fileName, vector<string> header);
    //////////////// append model ////////////////////////
    int writeVectorToTable(const vector<vector<string> > &infor, const vector<double> &v, string fileName); // append model
    int write2dVectorToTable(const vector<vector<string> > &infor, const vector<vector<double> > &v, string fileName); // append model
    ////////////// only one window /////////////////////
    int writeVectorToTable0(const vector<string> &infor, const vector<double> &v, string fileName, vector<string> header);
    int write2dVectorToTable0(const vector<string> &infor, const vector<vector<double> > &v, string fileName, vector<string> header);
private:

};

#endif	/* WRITEFILE_H */

