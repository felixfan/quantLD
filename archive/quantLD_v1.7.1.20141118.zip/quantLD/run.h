/* 
 * File:   run.h
 * Author: fan
 *
 * Created on October 7, 2014, 2:35 PM
 */

#ifndef RUN_H
#define	RUN_H

#include <fstream>

#include "pairwisePops.h"
#include "writeFile.h"
#include "readData.h"
#include "calLD.h"


using namespace std;

class run {
public:
    run();
    run(const run& orig);
    virtual ~run();
    int runQuantLDOne(string fileName1, string fileName2, int fPM, string method, int perm, string ldMeasure, string ldMethod, string outName, string fromBP, string toBP, bool fisher);
    void runQuantLDStep(string fileName1, string fileName2, int fPM, int windowSize, string method, int perm, string ldMeasure, string ldMethod,bool fisher, string outName, int maxWin);   
private:
    pairwisePops pwp;
    writeFile wf;
    readData rf;
    calLD myCalLD;
};

#endif	/* RUN_H */

