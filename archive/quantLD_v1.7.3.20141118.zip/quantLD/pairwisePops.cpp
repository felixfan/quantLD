/* 
 * File:   pairwisePops.cpp
 * Author: fan
 * 
 * Created on September 22, 2014, 4:08 PM
 */
#include <iostream>
#include <vector>
#include <string>

#include "pairwisePops.h"


pairwisePops::pairwisePops() {
}

pairwisePops::pairwisePops(const pairwisePops& orig) {
}

pairwisePops::~pairwisePops() {
}

// Tmethod, Tpercent, EVD
vector<double> pairwisePops::pwTMTPEVD(const vector<vector<double> > &fr, const vector<vector<double> > &sr, int windowSize, string method){  
    vector<double> result;
    
    for(auto i=fr.begin(),j=sr.begin(); i<fr.end(); i++, j++){
        MatrixXd mat1(windowSize,windowSize);
        MatrixXd mat2(windowSize,windowSize);
        mat1 = amv.vectorToMatrix(&(*i), windowSize, true);
        mat2 = amv.vectorToMatrix(&(*j), windowSize, true);
        if(method == "tmethod"){
            result.push_back(pwm.Tmethod(mat1,mat2,windowSize));
        }else if(method == "tpercent"){
            result.push_back(pwm.Tpercent(mat1,mat2,windowSize));
        }else if(method == "eigenvalue"){
            result.push_back(pwm.EigenValueDiff(mat1,mat2));
        }else if(method == "frobenius"){
            result.push_back(dist.FrobeniusDist(mat1,mat2,windowSize));
        }else if(method == "manhattan"){
            result.push_back(dist.ManhattanDist(mat1,mat2,windowSize));
        }else if(method == "maxsum"){
            result.push_back(dist.oneNorm(mat1,mat2,windowSize));
        }else if(method == "canberra"){
            result.push_back(dist.CanberraDist(mat1,mat2,windowSize));
        }else if(method == "chebyshev"){
            result.push_back(dist.ChebysheDist(mat1,mat2,windowSize));
        }  
    }
    return result; 
}

vector<vector<double> > pairwisePops::pwTMTPEVDperm(const vector<vector<double> > &fr, const vector<vector<double> > &sr, const vector<vector<int> > &genoCode1, const vector<vector<int> > &genoCode2, int windowSize, string method, int perm, int n1, int n2, string ldMeasure, string ldMethod){
    vector<double> org;
    
    for(auto i=fr.begin(),j=sr.begin(); i<fr.end(); i++, j++){
        MatrixXd mat1(windowSize,windowSize);
        MatrixXd mat2(windowSize,windowSize);
        mat1 = amv.vectorToMatrix(&(*i), windowSize, true);
        mat2 = amv.vectorToMatrix(&(*j), windowSize, true);
        if(method == "tmethod"){
            org.push_back(pwm.Tmethod(mat1,mat2,windowSize));
        }else if(method == "tpercent"){
            org.push_back(pwm.Tpercent(mat1,mat2,windowSize));
        }else if(method == "eigenvalue"){
            org.push_back(pwm.EigenValueDiff(mat1,mat2));
        }else if(method == "frobenius"){
            org.push_back(dist.FrobeniusDist(mat1,mat2,windowSize));
        }else if(method == "manhattan"){
            org.push_back(dist.ManhattanDist(mat1,mat2,windowSize));
        }else if(method == "maxsum"){
            org.push_back(dist.oneNorm(mat1,mat2,windowSize));
        }else if(method == "canberra"){
            org.push_back(dist.CanberraDist(mat1,mat2,windowSize));
        }else if(method == "chebyshev"){
            org.push_back(dist.ChebysheDist(mat1,mat2,windowSize));
        }        
    }
    
    // permutation 
    // cout << "permutation ... " << endl;
    int totw = genoCode1.size()-windowSize+1; // total number of windows
    vector<double> mcp(totw); // permutation p value
    
    // initialize permutation p value
    for(int i=0; i< totw; i++){
        mcp[i]=1.0;
    }
    
    for(int i=0; i<perm; i++){
        cout << " " << i+1 << "/" << perm << " ... " <<endl;
        vector<vector<int> > simGC1 = mcpm.mcperm(genoCode1, genoCode2, n1);
        vector<vector<int> > simGC2 = mcpm.mcperm(genoCode1, genoCode2, n2);
        
        vector<vector<double> > mcfr, mcsr;
    
        mcfr = myCalLD.calRD(simGC1, windowSize, ldMeasure, ldMethod);
        mcsr = myCalLD.calRD(simGC2, windowSize, ldMeasure, ldMethod);
   
        vector<double> sim;
    
        for(auto i=mcfr.begin(),j=mcsr.begin(); i<mcfr.end(); i++, j++){
            MatrixXd mat1(windowSize,windowSize);
            MatrixXd mat2(windowSize,windowSize);
            mat1 = amv.vectorToMatrix(&(*i), windowSize, true);
            mat2 = amv.vectorToMatrix(&(*j), windowSize, true);
            if(method == "tmethod"){
                sim.push_back(pwm.Tmethod(mat1,mat2,windowSize));
            }else if(method == "tpercent"){
                sim.push_back(pwm.Tpercent(mat1,mat2,windowSize));
            }else if(method == "eigenvalue"){
                sim.push_back(pwm.EigenValueDiff(mat1,mat2));
            }else if(method == "frobenius"){
                sim.push_back(dist.FrobeniusDist(mat1,mat2,windowSize));
            }else if(method == "manhattan"){
                sim.push_back(dist.ManhattanDist(mat1,mat2,windowSize));
            }else if(method == "maxsum"){
                sim.push_back(dist.oneNorm(mat1,mat2,windowSize));
            }else if(method == "canberra"){
                sim.push_back(dist.CanberraDist(mat1,mat2,windowSize));
            }else if(method == "chebyshev"){
                sim.push_back(dist.ChebysheDist(mat1,mat2,windowSize));
            }        
        }
                
        for(int i=0; i<sim.size(); i++){
            if(sim[i] > org[i]){
                mcp[i]++;
            }
        }
    }
    
    cout << endl;
    // p value: (m+1)/(n+1)
    for(int i=0; i<mcp.size(); i++){   
        mcp[i]/=(perm+1.0);
    }
    
    vector<vector<double> > results;
    for(auto i=org.begin(), j=mcp.begin(); i<org.end();i++,j++){
        vector<double> result;
        result.push_back(*i);
        result.push_back(*j);
        results.push_back(result);
    }
    return results; 
}


// ALL, Jennrich Test & SteigerTest
vector<vector<double> > pairwisePops::pwSTJTALL(const vector<vector<double> > &fr, const vector<vector<double> > &sr, int windowSize, string method, int n1, int n2, bool fisher){
    vector<vector<double> > results;
    
    for(auto i=fr.begin(),j=sr.begin(); i<fr.end(); i++, j++){
        MatrixXd mat1(windowSize,windowSize);
        MatrixXd mat2(windowSize,windowSize);
        mat1 = amv.vectorToMatrix(&(*i), windowSize, true);
        mat2 = amv.vectorToMatrix(&(*j), windowSize, true);
                
        // result order (all): ST.P ST.Chisq ST.df JT.P JT.Chisq JT.df TM TP EVD FD MHD MSD CAD CHD 
        // result order (ST): ST.P ST.Chisq ST.df
        // result order (JT): JT.P JT.Chisq JT.df
        if(method == "all"){
            vector<double> result;
            vector<double> temp = pwm.SteigerTest(mat1,mat2,windowSize,n1,n2,fisher);
            for(auto i=temp.begin(); i< temp.end(); i++){
                auto x = *i;
                result.push_back(x);
            }

            temp = pwm.JennrichTest(mat1,mat2,windowSize,n1,n2);
            for(auto i=temp.begin(); i< temp.end(); i++){
                auto x = *i;
                result.push_back(x);
            }

            result.push_back(pwm.Tmethod(mat1,mat2,windowSize));
            result.push_back(pwm.Tpercent(mat1,mat2,windowSize));
            result.push_back(pwm.EigenValueDiff(mat1,mat2));
            result.push_back(dist.FrobeniusDist(mat1,mat2,windowSize));
            result.push_back(dist.ManhattanDist(mat1,mat2,windowSize));
            result.push_back(dist.oneNorm(mat1,mat2,windowSize));
            result.push_back(dist.CanberraDist(mat1,mat2,windowSize));
            result.push_back(dist.ChebysheDist(mat1,mat2,windowSize));
            
            results.push_back(result);
        }else if(method == "steiger"){
            results.push_back(pwm.SteigerTest(mat1,mat2,windowSize,n1,n2,fisher));
        }else if(method == "jennrich"){
            results.push_back(pwm.JennrichTest(mat1,mat2,windowSize,n1,n2));
        }  
    }
    return results;
}



vector<vector<double> > pairwisePops::pwAllPerm(const vector<vector<double> > &fr, const vector<vector<double> > &sr, const vector<vector<int> > &genoCode1, const vector<vector<int> > &genoCode2, int windowSize, int perm, int n1, int n2, string ldMeasure, string ldMethod, bool fisher){    
    vector<vector<double> > results;
    vector<double> tms;
    vector<double> tps;
    vector<double> evs;
    vector<double> fd;
    vector<double> mhd;
    vector<double> msd;
    vector<double> cad;
    vector<double> chd;
    
    for(auto i=fr.begin(),j=sr.begin(); i<fr.end(); i++, j++){
        MatrixXd mat1(windowSize,windowSize);
        MatrixXd mat2(windowSize,windowSize);
        mat1 = amv.vectorToMatrix(&(*i), windowSize, true);
        mat2 = amv.vectorToMatrix(&(*j), windowSize, true);
        
        vector<double> result;
        result.reserve(22);
        // result order: ST.P ST.Chisq ST.df JT.P JT.Chisq JT.df TM TP EVD FD MHD MSD CAD CHD TM.P TP.P EVD.P FD.P MHD.P MSD.P CAD.P CHD.P
        tms.push_back(pwm.Tmethod(mat1,mat2,windowSize));
        tps.push_back(pwm.Tpercent(mat1,mat2,windowSize));
        evs.push_back(pwm.EigenValueDiff(mat1,mat2));
        fd.push_back(dist.FrobeniusDist(mat1,mat2,windowSize));
        mhd.push_back(dist.ManhattanDist(mat1,mat2,windowSize));
        msd.push_back(dist.oneNorm(mat1,mat2,windowSize));
        cad.push_back(dist.CanberraDist(mat1,mat2,windowSize));
        chd.push_back(dist.ChebysheDist(mat1,mat2,windowSize));
        
        vector<double> temp = pwm.SteigerTest(mat1,mat2,windowSize,n1,n2, fisher);
        for(auto i=temp.begin(); i< temp.end(); i++){
            auto x = *i;
            result.push_back(x);
        }
        
        temp = pwm.JennrichTest(mat1,mat2,windowSize,n1,n2);
        for(auto i=temp.begin(); i< temp.end(); i++){
            auto x = *i;
            result.push_back(x);
        }
        
        results.push_back(result);
    }
    
    //permutation
    // cout << "permutation ... " << endl;
    int totw = genoCode1.size()-windowSize+1; // total number of windows
    // permutation p value
    vector<double> mcptm(totw); 
    vector<double> mcptp(totw); 
    vector<double> mcpev(totw); 
    vector<double> mcpfd(totw);
    vector<double> mcpmhd(totw);
    vector<double> mcpmsd(totw);
    vector<double> mcpcad(totw);
    vector<double> mcpchd(totw);
    
    // initialize permutation p value
    for(int i=0; i< totw; i++){
        mcptm[i]=1.0;
        mcptp[i]=1.0;
        mcpev[i]=1.0;
        mcpfd[i]=1.0;
        mcpmhd[i]=1.0;
        mcpmsd[i]=1.0;
        mcpcad[i]=1.0;
        mcpchd[i]=1.0;
    }
    
    for(int i=0; i<perm; i++){
        // cout << " " << i+1 << "/" << perm << " ... " <<endl;
        vector<vector<int> > simGC1 = mcpm.mcperm(genoCode1,genoCode2,n1);
        vector<vector<int> > simGC2 = mcpm.mcperm(genoCode1,genoCode2,n2);
        
        vector<vector<double> > mcfr, mcsr;
    
        mcfr = myCalLD.calRD(simGC1, windowSize, ldMeasure, ldMethod);
        mcsr = myCalLD.calRD(simGC2, windowSize, ldMeasure, ldMethod);
    
        vector<double> simtms, simtps, simevs, simfd, simmhd, simmsd, simcad,simchd;
    
        for(auto i=mcfr.begin(),j=mcsr.begin(); i<mcfr.end(); i++, j++){
            MatrixXd mat1(windowSize,windowSize);
            MatrixXd mat2(windowSize,windowSize);
            mat1 = amv.vectorToMatrix(&(*i), windowSize, true);
            mat2 = amv.vectorToMatrix(&(*j), windowSize, true);
            simevs.push_back(pwm.EigenValueDiff(mat1,mat2));
            simtms.push_back(pwm.Tmethod(mat1,mat2, windowSize));
            simtps.push_back(pwm.Tpercent(mat1,mat2, windowSize));
            simfd.push_back(dist.FrobeniusDist(mat1,mat2, windowSize));
            simmhd.push_back(dist.ManhattanDist(mat1,mat2, windowSize));
            simmsd.push_back(dist.oneNorm(mat1,mat2, windowSize));
            simcad.push_back(dist.CanberraDist(mat1,mat2, windowSize));
            simchd.push_back(dist.ChebysheDist(mat1,mat2, windowSize));
        }
        
        for(int i=0; i<simevs.size(); i++){
            if(simevs[i] > evs[i]){
                mcpev[i]++;
            }
            if(simtms[i] > tms[i]){
                mcptm[i]++;
            }
            if(simtps[i] > tps[i]){
                mcptp[i]++;
            }
            if(simfd[i]>fd[i]){
                mcpfd[i]++;
            }
            if(simmhd[i]>mhd[i]){
                mcpmhd[i]++;
            }
            if(simmsd[i]>msd[i]){
                mcpmsd[i]++;
            }
            if(simcad[i]>cad[i]){
                mcpcad[i]++;
            }
            if(simchd[i]>chd[i]){
                mcpchd[i]++;
            }
        }
    }
    cout << endl;
    
    // p value: (m+1)/(n+1)
    for(int i=0; i<mcpev.size(); i++){   
        mcpev[i]/=(perm+1.0);
        mcptm[i]/=(perm+1.0);
        mcptp[i]/=(perm+1.0);
        mcpfd[i]/=(perm+1.0);
        mcpmhd[i]/=(perm+1.0);
        mcpmsd[i]/=(perm+1.0);
        mcpcad[i]/=(perm+1.0);
        mcpchd[i]/=(perm+1.0);
    }
    
    // result order: ST.P ST.Chisq ST.df JT.P JT.Chisq JT.df TM TP EVD FD MHD MSD CAD CHD TM.P TP.P EVD.P FD.P MHD.P MSD.P CAD.P CHD.P
    auto xi=results.begin();
    auto xj=tms.begin(), xk=mcptm.begin(), xl=tps.begin(), xm=mcptp.begin(), xn= evs.begin(), xo=mcpev.begin();
    auto xp=fd.begin(), xq=mcpfd.begin(), xr=mhd.begin(), xs=mcpmhd.begin(), xt=msd.begin(),xu=mcpmsd.begin();
    auto xv=cad.begin(), xw=mcpcad.begin(), xx=chd.begin(), xy=mcpchd.begin();
    for(; xi<results.end();xi++,xj++,xk++,xl++,xm++,xn++,xo++,xp++,xq++,xr++,xs++,xt++,xu++,xv++,xw++,xx++,xy++){
        // statistic
        xi -> push_back(*xj);
        xi -> push_back(*xl);
        xi -> push_back(*xn);
        xi -> push_back(*xp);
        xi -> push_back(*xr);
        xi -> push_back(*xt);
        xi -> push_back(*xv);
        xi -> push_back(*xx);
        // p value
        xi -> push_back(*xk);       
        xi -> push_back(*xm);        
        xi -> push_back(*xo);
        xi -> push_back(*xq);
        xi -> push_back(*xs);
        xi -> push_back(*xu);
        xi -> push_back(*xw);
        xi -> push_back(*xy);
    }
    
    return results;
}
