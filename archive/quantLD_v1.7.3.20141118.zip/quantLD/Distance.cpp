/* 
 * File:   Distance.cpp
 * Author: felixfan
 * 
 * Created on November 17, 2014, 4:56 PM
 */

#include "Distance.h"

Distance::Distance() {
}

Distance::Distance(const Distance& orig) {
}

Distance::~Distance() {
}

double Distance::MinkowskiDist(const MatrixXd &mf, const MatrixXd &ms, int n, double p){
    /*
     * Minkowski Distance
     */
    double diag = 0;
    double upper =0;
    for(int i=0; i<n; i++){
        diag += pow(abs(mf(i,i) - ms(i,i)),p);
        for(int j=i+1; j<n; j++){
            upper += pow(abs(mf(i,j) - ms(i,j)), p);
        }
    }
    double result = diag + upper * 2;
    result = pow(result, 1/p);
    return result;
}



double Distance::FrobeniusDist(const MatrixXd &mf, const MatrixXd &ms, int n){
    /*
     Frobenius Distance
     * MinkowskiDist with p =2
     */
    
    double result = MinkowskiDist(mf,ms,n,2.0);
    return result;
}


double Distance::ManhattanDist(const MatrixXd &mf, const MatrixXd &ms, int n){
    /*
     Manhattan Distance
     * MinkowskiDist with p =1
     */
    
    double result = MinkowskiDist(mf,ms,n,1.0);
    return result;
}

double Distance::ChebysheDist(const MatrixXd &mf, const MatrixXd &ms, int n){
    /*
     * Chebyshe Distance
     * MinkowskiDist with p -> infinity
     */
    
    double maxmax = 0;
    for(int i=0; i<n; i++){
        for(int j=i; j<n; j++){
            maxmax = abs(mf(i,j) - ms(i,j)) > maxmax ? abs(mf(i,j) - ms(i,j)) : maxmax;
        }
    }
    return maxmax;
}

double Distance::oneNorm(const MatrixXd &mf, const MatrixXd &ms, int n){
    /*
     The 1-norm: the maximum absolute column sum
     */
    MatrixXd md(n, n);
    md = mf - ms;
    
    double maxColSum =0;
    for(int i=0; i<n; i++){
        double colSum=0;
        for(int j=0; j<n; j++){
            colSum += abs(md(j,i));
        }
        if(colSum > maxColSum){
            maxColSum = colSum;
        }
    }
    
    return maxColSum;
}

double Distance::infNorm(const MatrixXd &mf, const MatrixXd &ms, int n){
    /*
     The infinity norm: the maximum absolute row sum
     */
    
    MatrixXd md(n, n);
    md = mf - ms;
    
    double maxRowSum =0;
    for(int i=0; i<n; i++){
        double rowSum=0;
        for(int j=0; j<n; j++){
            rowSum += abs(md(i,j));
        }
        if(rowSum > maxRowSum){
            maxRowSum = rowSum;
        }
    }
    
    return maxRowSum;
}


double Distance::CanberraDist(const MatrixXd &mf, const MatrixXd &ms, int n){
    double diag = 0;
    double upper =0;
    for(int i=0; i<n; i++){
        diag += abs(mf(i,i) - ms(i,i))/(abs(mf(i,i) + abs(ms(i,i))));
        for(int j=i+1; j<n; j++){
            upper += abs(mf(i,j) - ms(i,j))/(abs(mf(i,j) + abs(ms(i,j))));
        }
    }
    double result = diag + upper * 2;
    return result;
}

